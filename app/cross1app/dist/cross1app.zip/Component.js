sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("cross1app.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map